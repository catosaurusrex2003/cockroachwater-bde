import os
from pymongo import MongoClient
from bson.json_util import dumps

client = MongoClient(host=os.environ.get("ATLAS_URI"))

recomendationCollection = client.bde.songrecom


def queryAllUserRecom():
    """
    Queries data base for all Users Recomendation Data.
    Args:
        NOTHING
    Return:
        The array of Users Data
    """
    result = recomendationCollection.find()
    allRecommendations = list(result)
    return dumps(allRecommendations)


def lambda_handler(event, context):
    # Name of database
    recomData = queryAllUserRecom()
    return {"data": recomData}
